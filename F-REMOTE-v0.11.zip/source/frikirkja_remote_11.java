import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import themidibus.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class frikirkja_remote_11 extends PApplet {

//Frikirkja MIDI Remote Console
//Program to manage remote organ console with MIDI keyboard
//Aki Asgeirsson
//November 2017



//note events on display?
//combinations 
//midi panic
//split keyboard

//ath
// inverted ctl 
// hangandi registur\

// hljombord
// bassi er hljombord 1
// 1 er 2
// 2 er 3
// 3 er 1



int test = 0;
 

MidiBus myBus; 

int midiChannelForNoteEvents = 1;
int functionForControlPedal = 2;
int activeCombination = 4;

Stop[] stops;
ControlPedal cres, schwell1, schwell2;
Keyboard bass, man1, man2, man3;
Comb[] buttons;

Save saveButton;

int pink = color(255, 111, 200);
int white = color(255, 244, 244);
int blue =  color(111, 177, 244);
int green =  color(222, 233, 128);

int dark = color(50);
int gray = color(125);
int light = color(200);

int bg = color(88);


public void setup() {
  
  background(bg);
  frameRate(30);

  MidiBus.list(); 
  // user choose input 
  //MidiBus.availableInputs().length


  myBus = new MidiBus(this, "USB MIDI Interface", "USB MIDI Interface"); 

  schwell1 = new ControlPedal(1);
  cres = new ControlPedal(2);
  schwell2 = new ControlPedal(3);

  bass = new Keyboard(0);
  man1 = new Keyboard(1);
  man2 = new Keyboard(2);
  man3 = new Keyboard(7);
  
  saveButton = new Save();

  // Stop(String name_in, String foot_in, String upperColor_in, String lowerColor_in, int midiChan, int midinr_in, String leftRight_in, int row_in, int column_in) 
  stops = new Stop[63];
  stops[0] = new Stop("ekkert", "8'", "pink", "pink", 13, 22, "left", -1, 0);

  stops[1] = new Stop("Fl\u00f6t", "8'", "pink", "pink", 2, 1, "left", 1, 0);
  stops[2] = new Stop("R\u00f6hr", "8'", "pink", "pink", 2, 3, "left", 1, 1);
  stops[3] = new Stop("Viola", "8'", "pink", "pink", 2, 5, "left", 1, 2);
  stops[4] = new Stop("Bach", "4'", "pink", "pink", 2, 7, "left", 1, 3);
  stops[5] = new Stop("Violin", "4'", "pink", "pink", 2, 9, "left", 1, 4);
  stops[6] = new Stop("Princip", "2'", "pink", "pink", 2, 11, "left", 1, 5);
  stops[7] = new Stop("Picc", "2'", "pink", "pink", 2, 13, "left", 1, 6);
  stops[8] = new Stop("Sesq", "2f", "pink", "pink", 2, 15, "left", 1, 7);
  stops[9] = new Stop("Acuta", "3-4f", "pink", "pink", 2, 17, "left", 1, 8);
  stops[10] = new Stop("Rank", "16'", "pink", "pink", 2, 19, "left", 1, 9);
  stops[11] = new Stop("Krumm", "8'", "pink", "pink", 2, 21, "left", 1, 10);
  stops[12] = new Stop("III/II", " ", "blue", "pink", 2, 23, "left", 1, 11);

  stops[13] = new Stop("Bordun", "16'", "white", "white", 1, 1, "left", 2, 0);
  stops[14] = new Stop("Princi", "8'", "white", "white", 1, 3, "left", 2, 1);
  stops[15] = new Stop("FlHarm", "8'", "white", "white", 1, 5, "left", 2, 2);
  stops[16] = new Stop("VlGamb", "8'", "white", "white", 1, 7, "left", 2, 3);
  stops[17] = new Stop("Dulci", "8'", "white", "white", 1, 9, "left", 2, 4);
  stops[18] = new Stop("Oktav", "4'", "white", "white", 1, 11, "left", 2, 5);
  stops[19] = new Stop("Fl\u00f6te", "4'", "white", "white", 1, 13, "left", 2, 6);
  stops[20] = new Stop("Oktav", "2'", "white", "white", 1, 15, "left", 2, 7);
  stops[21] = new Stop("Mixt", "4-5f'", "white", "white", 17, 1, "left", 2, 8);
  stops[22] = new Stop("Trp", "8'", "white", "white", 1, 19, "left", 2, 9);
  stops[23] = new Stop("II/I", " ", "pink", "white", 1, 21, "left", 2, 10);
  stops[24] = new Stop("III/I", " ", "blue", "white", 1, 23, "left", 2, 11);

  stops[25] = new Stop("Sub", "I", "white", "white", 1, 25, "left", 3, 2);
  stops[26] = new Stop("Super", "I", "white", "white", 1, 27, "left", 3, 3);
  stops[27] = new Stop("Sub", "II/I", "pink", "white", 1, 29, "left", 3, 4);
  stops[28] = new Stop("Super", "II/I", "pink", "white", 1, 31, "left", 3, 5);
  stops[29] = new Stop("Sub", "III/I", "blue", "white", 1, 33, "left", 3, 6);
  stops[30] = new Stop("Super", "III/I", "blue", "white", 1, 35, "left", 3, 7);
  stops[31] = new Stop("Sub", "III/II", "blue", "pink", 2, 25, "left", 3, 8);
  stops[32] = new Stop("Super", "III/II", "blue", "pink", 2, 27, "left", 3, 9);
  stops[33] = new Stop("Sub", "II", "pink", "pink", 2, 29, "left", 3, 10);
  stops[34] = new Stop("Super", "II", "pink", "pink", 2, 31, "left", 3, 11);

  stops[35] = new Stop("Lieb", "16'", "blue", "blue", 3, 1, "right", 1, 0);
  stops[36] = new Stop("Geige", "8'", "blue", "blue", 3, 3, "right", 1, 1);
  stops[37] = new Stop("Konz", "8'", "blue", "blue", 3, 5, "right", 1, 2);
  stops[38] = new Stop("Quint", "8'", "blue", "blue", 3, 7, "right", 1, 3);
  stops[39] = new Stop("Aeol", "8'", "blue", "blue", 3, 9, "right", 1, 4);
  stops[40] = new Stop("Vox", "8'", "blue", "blue", 3, 11, "right", 1, 5);
  stops[41] = new Stop("Fuga", "4'", "blue", "blue", 3, 13, "right", 1, 6);
  stops[42] = new Stop("Flauto", "4'", "blue", "blue", 3, 15, "right", 1, 7);
  stops[43] = new Stop("Flauti", "2'", "blue", "blue", 3, 17, "right", 1, 8);
  stops[44] = new Stop("Harm", "3f", "blue", "blue", 3, 19, "right", 1, 9);
  stops[45] = new Stop("Oboe", "8'", "blue", "blue", 3, 21, "right", 1, 10);

  stops[46] = new Stop("Contra", "16'", "green", "green", 8, 1, "right", 2, 0);
  stops[47] = new Stop("Subb", "16'", "green", "green", 8, 3, "right", 2, 1);
  stops[48] = new Stop("Echo", "16'", "green", "green", 8, 5, "right", 2, 2);
  stops[49] = new Stop("BFl", "16'", "green", "green", 8, 7, "right", 2, 3);
  stops[50] = new Stop("Cello", "16'", "green", "green", 8, 9, "right", 2, 4);
  stops[51] = new Stop("Fl\u00f6te", "16'", "green", "green", 8, 11, "right", 2, 5);
  stops[52] = new Stop("Hinter", "16'", "green", "green", 8, 13, "right", 2, 6);
  stops[53] = new Stop("Bsn", "16'", "green", "green", 8, 15, "right", 2, 7);
  stops[54] = new Stop("Pos", "16'", "green", "green", 8, 17, "right", 2, 8);
  stops[55] = new Stop("Zimbel", "16'", "white", "white", 8, 19, "right", 2, 10);

  stops[56] = new Stop(" ", "I/P", "white", "green", 8, 21, "right", 3, 0);
  stops[57] = new Stop(" ", "II/P", "white", "green", 8, 23, "right", 3, 1);
  stops[58] = new Stop(" ", "III/P", "white", "green", 8, 25, "right", 3, 2);
  stops[59] = new Stop("Super", "II/P", "white", "green", 8, 27, "right", 3, 3);
  stops[60] = new Stop("Sub", "III", "blue", "blue", 3, 23, "right", 3, 5);
  stops[61] = new Stop("Super", "III", "blue", "blue", 3, 25, "right", 3, 6);
  stops[62] = new Stop("Trem", "III", "blue", "blue", 3, 27, "right", 3, 8);

  buttons = new Comb[40];
  buttons[0] = new Comb(1, '1', 0, 0);
  buttons[1] = new Comb(2, '2', 0, 1);
  buttons[2] = new Comb(3, '3', 0, 2);
  buttons[3] = new Comb(4, '4', 0, 3);
  buttons[4] = new Comb(5, '5', 0, 4);
  buttons[5] = new Comb(6, '6', 0, 5);
  buttons[6] = new Comb(7, '7', 0, 6);
  buttons[7] = new Comb(8, '8', 0, 7);
  buttons[8] = new Comb(9, '9', 0, 8);
  buttons[9] = new Comb(10, '0', 0, 9);

  buttons[10] = new Comb(11, 'q', 1, 0);
  buttons[11] = new Comb(12, 'w', 1, 1);
  buttons[12] = new Comb(13, 'e', 1, 2);
  buttons[13] = new Comb(14, 'r', 1, 3);
  buttons[14] = new Comb(15, 't', 1, 4);
  buttons[15] = new Comb(16, 'y', 1, 5);
  buttons[16] = new Comb(17, 'u', 1, 6);
  buttons[17] = new Comb(18, 'i', 1, 7);
  buttons[18] = new Comb(19, 'o', 1, 8);
  buttons[19] = new Comb(20, 'p', 1, 9);

  buttons[20] = new Comb(21, 'a', 2, 0);
  buttons[21] = new Comb(22, 's', 2, 1);
  buttons[22] = new Comb(23, 'd', 2, 2);
  buttons[23] = new Comb(24, 'f', 2, 3);
  buttons[24] = new Comb(25, 'g', 2, 4);
  buttons[25] = new Comb(26, 'h', 2, 5);
  buttons[26] = new Comb(27, 'j', 2, 6);
  buttons[27] = new Comb(28, 'k', 2, 7);
  buttons[28] = new Comb(29, 'l', 2, 8);
  buttons[29] = new Comb(30, '\u00e6', 2, 9);

  buttons[30] = new Comb(31, 'z', 3, 0);
  buttons[31] = new Comb(32, 'x', 3, 1);
  buttons[32] = new Comb(33, 'c', 3, 2);
  buttons[33] = new Comb(34, 'v', 3, 3);
  buttons[34] = new Comb(35, 'b', 3, 4);
  buttons[35] = new Comb(36, 'n', 3, 5);
  buttons[36] = new Comb(37, 'm', 3, 6);
  buttons[37] = new Comb(38, ',', 3, 7);
  buttons[38] = new Comb(39, '.', 3, 8);
  buttons[39] = new Comb(40, '\u00fe', 3, 9);


  schwell1.display();
  cres.display();
  schwell2.display();

  bass.display();
  man1.display();
  man2.display();
  man3.display();

  for (int i=1; i<63; i++) {
    stops[i].display();
  }

  for (int i=0; i<40; i++) {
    buttons[i].display();
  }
  
  saveButton.display();
  
  fill(0);
  textSize(22);
  textAlign(LEFT);
  text("Fr\u00edkirkja Remote MIDI Control, v0.11", 50, height-55);
  textAlign(RIGHT);
  text("\u00c1ki \u00c1sgeirsson, 2017", width-50, height-55);
  textAlign(CENTER,CENTER);
}

public void draw() {
  schwell1.fade();
  cres.fade();
  schwell2.fade();
  saveButton.fade();
}





public void sendProgramChange(int channel, int number ) {
  myBus.sendMessage(0xC0, channel, number, 0);
}


public void controllerChange(ControlChange change) {
  // Receive a controllerChange
  if (functionForControlPedal == 1) schwell1.change(change.value());
  if (functionForControlPedal == 2) cres.change(change.value());
  if (functionForControlPedal == 3) schwell2.change(change.value());
}

public void noteOn(Note note) {
  // Receive a noteOn
  myBus.sendNoteOn(midiChannelForNoteEvents, note.pitch(), note.velocity());
  // noteBlink(midiChannelForNoteEvents);
}

public void noteOff(Note note) {
  // Receive a noteOff
  myBus.sendNoteOff(midiChannelForNoteEvents, note.pitch(), note.velocity());
}


public void mousePressed() {
  
  //buttons[1].save();
  
  for (int i=0; i<62; i++) {
    stops[i].click(mouseX, mouseY);
  }

  schwell1.click(mouseX, mouseY);
  schwell2.click(mouseX, mouseY);
  cres.click(mouseX, mouseY);
  bass.click(mouseX, mouseY);
  man1.click(mouseX, mouseY);
  man2.click(mouseX, mouseY);
  man3.click(mouseX, mouseY);

  for (int i=0; i<40; i++) {
    buttons[i].click(mouseX, mouseY);
  }
  
  saveButton.click(mouseX, mouseY);
}


public void keyPressed() {

  for (int i=0; i<40; i++) {
    buttons[i].press(key);
  }

  //arrow keys control pedal function and midi note out channel
  if (key == CODED) {

    if (keyCode == LEFT) {
      functionForControlPedal--;
      if (functionForControlPedal==0) functionForControlPedal = 3;
      schwell1.display();
      cres.display();
      schwell2.display();
    }
    if (keyCode == RIGHT) {
      functionForControlPedal++;
      if (functionForControlPedal==4) functionForControlPedal = 1;
      schwell1.display();
      cres.display();
      schwell2.display();
    }
    if (keyCode == UP) {
      midiChannelForNoteEvents++;
      if (midiChannelForNoteEvents==8) midiChannelForNoteEvents = 0;
      if (midiChannelForNoteEvents==3) midiChannelForNoteEvents = 7;
      bass.display();
      man1.display();
      man2.display();
      man3.display();
    }
    if (keyCode == DOWN) {
      midiChannelForNoteEvents--;
      if (midiChannelForNoteEvents==6) midiChannelForNoteEvents = 2;
      if (midiChannelForNoteEvents==-1) midiChannelForNoteEvents = 7;
      bass.display();
      man1.display();
      man2.display();
      man3.display();
    }
  }
  // combinations, memory presets
}




public void del(int time) {
  int current = millis();
  while (millis () < current+time) Thread.yield();
}
class Comb {

  char name;
  String nam;
  int id;
  boolean active = false;
  int x, y;
  int w, h;

  String[] combination;
  String filename;



  Comb(int id_in, char name_in, int row_in, int column_in) {

    name = name_in;
    id = id_in;

    combination = new String[63];


    int marginTop = 480;
    int spacingX = 90;
    int spacingY = 70;
    int marginLeft = 210+(30*row_in);

    w = 50;
    h = 50;

    x = marginLeft;

    x += column_in * spacingX;
    y = marginTop - h;
    y += row_in * spacingY;


    nam = str(name);
    nam = nam.toUpperCase();

    filename = "presets/combination-" + nam + ".txt";

    rectMode(CENTER);
    textAlign(CENTER, CENTER);
    //textSize(8);
  }

  public void display() {
    strokeWeight(1);
    stroke(0);
    if (activeCombination == id) {
      fill(gray);
    } else {
      fill(dark);
    }
    rect(x, y, w, h);

    textSize(24);
    fill(light);
    text(nam, x, y);
  }


  public void click(int mX, int mY) {
    if (mX>x-w/2 && mX<x+w/2 && mY>y-h/2 && mY<y+h/2) {
      activeCombination = id;
      load();
      for (int i=0; i<40; i++) {
        buttons[i].display();
      }
    }
  }

  public void press(char key_in) {
    if (key_in == name) {
      activeCombination = id;
      load();
      for (int i=0; i<40; i++) {
        buttons[i].display();
      }
    }
  }

  public void save() {
    String[] empty = { };
    combination = empty;
    for (int i=1; i<63; i++) {
      combination = append(combination, stops[i].get());
    }
    saveStrings(filename, combination);
  }

  public void load() {
    String[] lines = loadStrings(filename);
    for (int i = 0; i < lines.length; i++) {
      int onoff;
      if (lines[i].equals("1")) { 
        onoff = 1;
      } else {
        onoff = 0;
      }
      stops[i].activate(onoff);
    }
  }
}

class ControlPedal {
  String name;
  int id = 0;
  int x, y;
  int w, h;
  int value;
  int oldVal;
  int newVal;
  boolean selected;

  ControlPedal(int nr) {
    id = nr;
    w = 60;
    h = 40;
    rectMode(CENTER);
    value = 0;

    if (nr == 1) {
      name = "Schwell 1";
      x = (width/2) - 100;
      y = 80;
      oldVal = 64;
      newVal = 64;
    }

    if (nr == 2) {
      name = "Crescendo";
      x = width/2;
      y = 80;
      oldVal = 0;
      newVal = 0;
    }

    if (nr == 3) {
      name = "Schwell 2";
      x = (width/2) + 100;
      y = 80;
      oldVal = 64;
      newVal = 64;
    }
  }

  public void display() {

    fill(180);
    stroke(0);
    if (id == functionForControlPedal) {
      fill(light);
    } else { 
      fill(dark);
    }
    rect(x, y, w, h);


    fill(22);
    noStroke();
    float size = value/127.0f*w;
    rect(x, y, size, h);


    fill(244);
    textSize(11);
    text(name, x, y);
    strokeWeight(1);
  }


  public void click(int mX, int mY) {
    if (mX>x-w/2 && mX<x+w/2 && mY>y-h/2 && mY<y+h/2) {
      // clicked
      functionForControlPedal = id;
      schwell1.display();
      cres.display();
      schwell2.display();
    }
  }

  public void change(int val) {
    //println(val);

    if (id == 1) newVal = PApplet.parseInt(map(val, 0, 127, 64, 123));
    if (id == 2) newVal = PApplet.parseInt(map(val, 0, 127, 0, 31));
    if (id == 3) newVal = PApplet.parseInt(map(val, 0, 127, 64, 123));
  }

  public void fade() {

    if (id == 1) {
      if (newVal < oldVal) {
        oldVal--;
        myBus.sendControllerChange(0, 7, oldVal);
      }
      if (newVal > oldVal) {
        oldVal++;
        myBus.sendControllerChange(0, 7, oldVal);
      }
      display();
      value = PApplet.parseInt(map(oldVal, 64, 123, 0, 127));  // for display
    }

    if (id == 2) {
      if (newVal < oldVal) {
        oldVal--;
        cresc(oldVal);
        //println(" -- " + oldVal + " " );
      }
      if (newVal > oldVal) {
        oldVal++;
        cresc(oldVal);
        //println(" -- " + oldVal + " ");
      }
      value = PApplet.parseInt(map(oldVal, 0, 31, 0, 127));   // for display
    }

    if (id == 3) {
      if (newVal < oldVal) {
        oldVal--;
        myBus.sendControllerChange(1, 7, oldVal);
      }
      if (newVal > oldVal) {
        oldVal++;
        myBus.sendControllerChange(1, 7, oldVal);
      }
      value = PApplet.parseInt(map(oldVal, 64, 123, 0, 127));  // for display
      display();
    }
  }
}

class Keyboard {
  String name;
  int id = 0;
  int x, y;
  int w, h;
  int value;
  int oldVal;
  int newVal;
  boolean selected;
  boolean noteOn = false;
  //int blink = 180;

  Keyboard(int nr) {
    id = nr;
    w = 330;
    h = 25;
    rectMode(CENTER);
    value = 64;

    if (nr == 0) {
      name = "Pedal";
      x = (width/2);
      y = 350;
    }

    if (nr == 1) {
      name = "Manual I";
      x = (width/2);
      y = 250;
    }

    if (nr == 2) {
      name = "Manual II";
      x = (width/2);
      y = 200;
    }
    if (nr == 7) {
      name = "Manual III";
      x = (width/2);
      y = 150;
    }
  }

  public void display() {

    fill(180);
    stroke(0);
    if (id == midiChannelForNoteEvents) {
      fill(light);
    } else { 
      fill(dark);
    }
    rect(x, y, w, h);

    // midi note on activity
    if (noteOn) {
      fill(dark);
      noStroke();
      float noteX = map(value, 0, 127, x-(w/2), x+(w/2));
      ellipse(noteX, y, h, h);
    }

    fill(gray);
    textSize(11);
    text(name, x, y);
    strokeWeight(1);
  }

  //FIX
  public void click(int mX, int mY) {
    if (mX>x-w/2 && mX<x+w/2 && mY>y-h/2 && mY<y+h/2) {
      midiChannelForNoteEvents = id;
      bass.display();
      man1.display();
      man2.display();
      man3.display();
    }
  }
}

class Save {
  String name, nam;
  int x, y;
  int w, h;
  boolean active = false;
  int fadeCount = 0;

  Save() {
    name = "Save";
    x = 100;
    y = 550;
    w = 50;
    h = 50;
    rectMode(CENTER);
  }

  public void display() {


    if (active) {
      fill(light);
      nam = "saving";
    } else { 
      fill(dark);
      nam = name;
    }
    rect(x, y, w, h);

    fill(244);
    textSize(11);
    text(nam, x, y);
    strokeWeight(1);
  }


  public void click(int mX, int mY) {
    if (mX>x-w/2 && mX<x+w/2 && mY>y-h/2 && mY<y+h/2 && active==false) {
      // clicked
      active = true;
      fadeCount = 0;
      buttons[activeCombination-1].save();
      display();
    }
  }



  public void fade() {
    fadeCount++;
    if (fadeCount>30 && active) {
      active = false;
      display();
    }
  }
}
class Stop {

  String name, foot;
  int midiChan, midiNr;

  boolean active = false;
  int x, y;
  int w, h;

  int upperColor;
  int lowerColor;

  Stop(String name_in, String foot_in, String upperColor_in, String lowerColor_in, int midiChan_in, int midiNr_in, String leftRight_in, int row_in, int column_in) {

    name = name_in;
    foot = foot_in;
    midiChan = midiChan_in-1;
    midiNr = midiNr_in-1;

    int marginLeft = 35;
    int marginRight = (width/2)+219;
    int marginTop = 111;
    int spacingX = 35;
    int spacingY = 100;

    w = 28;
    h = 70;

    if (leftRight_in.equals("left")) x = marginLeft;
    if (leftRight_in.equals("right")) x = marginRight;

    x += column_in * spacingX;
    y = marginTop - h;
    y += row_in * spacingY;

    if (upperColor_in.equals("pink")) upperColor =  pink;
    if (upperColor_in.equals("white")) upperColor =  white;
    if (upperColor_in.equals("blue")) upperColor =  blue;
    if (upperColor_in.equals("green")) upperColor =  green;

    if (lowerColor_in.equals("pink")) lowerColor =  pink;
    if (lowerColor_in.equals("white")) lowerColor =  white;
    if (lowerColor_in.equals("blue")) lowerColor =  blue;
    if (lowerColor_in.equals("green")) lowerColor =  green;


    rectMode(CENTER);
    textAlign(CENTER, CENTER);
    //textSize(8);
  }

  public void display() {
    strokeWeight(1);
    stroke(0);
    fill(0);
    rect(x, y, w+2, h);

    textSize(8);

    int yOffset = -5;
    if (active) yOffset = 5;
    fill(light);
    rect(x, y+yOffset, w, h-10);
    // ellipse(x, y, w, w);
    fill(upperColor);
    arc(x, y+yOffset, w, w, radians(180), radians(360), OPEN);
    fill(lowerColor);
    arc(x, y+yOffset, w, w, radians(0), radians(180), OPEN);
    fill(22);
    text(name, x, y+yOffset-20);
    text(foot, x, y+yOffset+20);
  }


  public void click(int mX, int mY) {
    if (mX>x-w/2 && mX<x+w/2 && mY>y-h/2 && mY<y+h/2) {
      if (active) {
        active = false;
        sendProgramChange(midiChan, midiNr+1 );  //  Turn OFF
        display();
      } else { 
        active = true;
        sendProgramChange(midiChan, midiNr );  // Turn ON
        display();
      }
    }
  }

  public void activate(int onoff) {
    if (onoff==1) {
      if (active==false) {
        sendProgramChange(midiChan, midiNr-1 );  // ON
        active = true;
      }
    } else { 
      if (active==true) {
        sendProgramChange(midiChan, midiNr );  //  OFF
        active = false;
      }
    }
    display();
  }

  public String get() {
    String out;
    if (active) { 
      out="1";
    } else {
      out="0";
    }
    return out;
  }

  
}



int[][] crescArray = {  
  //.............................10............................20............................30............................40............................50............................60....
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, 
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0}, 
  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0}, 
  {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  //.............................10............................20............................30............................40............................50............................60.... 
  {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  //.............................10............................20............................30............................40............................50............................60.... 
  {0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0}, 
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0}, 
  //.............................10............................20............................30............................40............................50............................60....
  {0, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0}, 

};



public void cresc(int value) { 
  for (int i = 1; i < 63; i++) { 
    stops[i].activate(crescArray[value][i]);
   delay(1);
  };
}
  public void settings() {  size(1280, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--hide-stop", "frikirkja_remote_11" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
